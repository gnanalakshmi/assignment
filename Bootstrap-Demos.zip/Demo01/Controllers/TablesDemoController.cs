﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo01.Controllers
{
    public class TablesDemoController : Controller
    {
        // GET: TablesDemo
        public ActionResult Index()
        {
            return View();
        }
    }
}