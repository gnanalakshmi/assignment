﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo01.Controllers
{
    public class FlexboxDemoController : Controller
    {
        // GET: FlexboxDemo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult example1()
        {
            return PartialView("_example1");
        }

        public ActionResult example2()
        {
            return PartialView("_example2");
        }
        public ActionResult example3()
        {
            return PartialView("_example3");
        }
        public ActionResult example4()
        {
            return PartialView("_example4");
        }
        public ActionResult example5()
        {
            return PartialView("_example5");
        }
    }
}